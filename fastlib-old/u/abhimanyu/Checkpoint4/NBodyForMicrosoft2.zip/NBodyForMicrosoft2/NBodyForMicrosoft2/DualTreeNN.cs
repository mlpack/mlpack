using System;
using System.Diagnostics;
using System.Collections.Generic;
using System.Collections;
using System.Data.SqlTypes;
using Microsoft.SqlServer.Server;
using System.Data.SqlClient;
using System.IO;
using StructureInterfaces;
using Utilities;
using NBodyForMicrosoft2;


namespace Algorithms
{
    public class DualTreeNN
    {
        private TextWriterTraceListener Tracer;

        private double[] NodeMaxDst;// for each node in queryTree what is the max dist from closest node
        Dictionary<int, int> nodeIdIndexMapping;// key= node Id, value= index in double[] NodeMaxDst of req. data

        Dictionary<int, int> qIdIndexMapping;   // key= query point id, value= index in the following 3 data
                                                // data structs. note for nn's and dst's the effective index becomes 
                                                // value * kNN, whereas for maxDist it's value itself

        private int[] nns;          // for each query pt. holds k nn's
        private double[] dsts;      // for each query point holds the distances to the k nn's
        private double[] maxDist;   // for each query point holds the furthest nn till now

        private Dictionary<int, double[]> queryData;
        private Dictionary<int, int[]> queryIds;
        private Dictionary<int, double[]> refData;
        private Dictionary<int, int[]> refIds;

        
            
        public struct OutputData
        {
            public int queryPointId;
            public int referencePointId;
            public double distance;

            public OutputData(int qId, int rId, double dst)
            {
                queryPointId = qId;
                referencePointId = rId;
                distance = dst;
            }
        }

        
        public void OutputContract(object output, out SqlInt32 queryPointId, 
            out SqlInt32 referencePointId, out SqlDouble distance)
        {
            OutputData outputData = (OutputData)output;
            queryPointId = outputData.queryPointId;
            referencePointId = outputData.referencePointId;
            distance = outputData.distance;
        }

        private void SetupTracing()
        {
            if (Tracer == null)
            {
                Tracer = new
                 TextWriterTraceListener("C:\\Documents and Settings\\manyu\\Desktop\\trace.txt");
                Trace.Listeners.Add(Tracer);
            }

            Trace.WriteLine("Starting Trace.");
            Trace.Flush();
        }

        private void SetupEnvironment()
        {
            SetupTracing();
        }

        private void CloseEnvironment()
        {
            Trace.Flush();
            Trace.Close();
        }

        private void ReadDataPoints(String qTreeTableName, String rTreeTableName, int k)
        {
            SqlConnection connection = new SqlConnection();
            //connection.ConnectionString = "Context Connection=true";
            connection.ConnectionString = "Data Source=KLEENE; Initial Catalog=Master; Integrated Security=True;";
            connection.Open();
                       
            // get the query data
            TreeInfo qTreeInfo = TreeUtilities.GetTreeInfo(connection, qTreeTableName);
            String commText = TreeUtilities.GetNodeDataSQLQuery(qTreeInfo);
            SqlCommand comm = new SqlCommand(commText, connection);
            SqlDataReader rdr = comm.ExecuteReader();
            ParseAndStoreData(rdr, queryIds, queryData, k);
            Console.WriteLine(commText);
            rdr.Close();

            // get ref data
            TreeInfo rTreeInfo = TreeUtilities.GetTreeInfo(connection, rTreeTableName);
            commText = TreeUtilities.GetNodeDataSQLQuery(rTreeInfo);
            comm.CommandText = commText;
            rdr = comm.ExecuteReader();
            //Console.WriteLine("here");
            ParseAndStoreData(rdr, refIds, refData, k);
            connection.Close();
        }

        private void ParseAndStoreData(SqlDataReader rdr, 
            Dictionary<int, int[]> ids, Dictionary<int, double[]> data, int k)
        {
            int prevNodeId = -1;
            int nodeId;
            List<double> doubleList = new List<double>(50*k);
            List<int> idList = new List<int>(50);

            if( rdr.Read() )
            {
                nodeId = rdr.GetInt32(0);
                prevNodeId = nodeId;
                idList.Add(rdr.GetInt32(1));
                for (int i = 2; i < k + 2; ++i)
                {
                    doubleList.Add(rdr.GetDouble(i));
                }
            }
            else
            {
                throw new Exception();
            }

            
            while (rdr.Read())
            {
                nodeId = rdr.GetInt32(0);
                if (ids == refIds && nodeId == 557)
                    Console.WriteLine("here 1");
                if (nodeId != prevNodeId)
                {
                    // read the data and add to current data structures
                    data.Add(prevNodeId, doubleList.ToArray());
                    ids.Add(prevNodeId, idList.ToArray());
                    doubleList = new List<double>(50 * k);
                    idList = new List<int>(50);   
                }
                idList.Add(rdr.GetInt32(1));
                for (int i = 2; i < k + 2; ++i)
                {
                    doubleList.Add(rdr.GetDouble(i));
                }
                prevNodeId = nodeId;
            }
            data.Add(prevNodeId, doubleList.ToArray());
            ids.Add(prevNodeId, idList.ToArray());
                    
        }

        
        
        /// <summary>
        /// Given the Query tree which is the tree for which results are to be returned
        /// various data structures need to be setup for each query point, query node etc.
        /// This function handles that before the algorithm actually begins.
        /// </summary>
        /// <param name="queryTree"></param>
        /// <param name="kNN"></param>
        private void InitDataStructures(ITree queryTree, ITree refTree, 
            String qTreeTableName, String rTreeTableName, int kNN)
        {
            
            NodeMaxDst = new double[queryTree.GetNumNodes()];
            nodeIdIndexMapping = new Dictionary<int, int>(queryTree.GetNumNodes());

            qIdIndexMapping = new Dictionary<int, int>(queryTree.GetDataSize());
            nns = new int[kNN * queryTree.GetDataSize()];
            dsts = new double[kNN * queryTree.GetDataSize()];
            maxDist = new double[queryTree.GetDataSize()];

            queryData = new Dictionary<int, double[]>(queryTree.GetNumNodes());
            queryIds = new Dictionary<int, int[]>(queryTree.GetNumNodes());
            refData = new Dictionary<int, double[]>(refTree.GetNumNodes());
            refIds = new Dictionary<int, int[]>(refTree.GetNumNodes());

            ReadDataPoints(qTreeTableName, rTreeTableName, queryTree.GetDimensionality());

            double max = double.MaxValue;


            for (int i = 0; i < kNN * queryTree.GetDataSize(); ++i){
                dsts[i] = max;
            }

            for (int i = 0; i < queryTree.GetDataSize(); ++i){
                maxDist[i] = max;
            }
            

            
            INode[] nodes = queryTree.GetAllNodes();
            int count = 0;
            for (int i = 0; i < queryTree.GetNumNodes(); ++i){
                nodeIdIndexMapping.Add(nodes[i].GetNodeId(),i);
                NodeMaxDst[i] = max;
                // noe update the queryPt index mapping data structure
                int[] qPointIds;
                //Console.WriteLine(nodes[i].GetNodeId());
                if (queryIds.TryGetValue(nodes[i].GetNodeId(), out qPointIds))
                {
                    for (int j = 0; j < qPointIds.Length; j++)
                    {
                        qIdIndexMapping.Add(qPointIds[j], count);
                        count++;
                    }
                }
            }
            
        }




        [SqlFunction(Name = "NN",
        DataAccess = DataAccessKind.Read,
        IsDeterministic = true,
        IsPrecise = true,
        TableDefinition = "QueryPointId int, ReferencePointId int, Distance double",
        FillRowMethodName = "OutputContract")]
        public IEnumerable GetNearestNeighbors(
            String qTreeTableName, String rTreeTableName, int kNN)
        {
            SetupEnvironment();
            try
            {
                Trace.WriteLine("Read data from tables");
                Trace.Flush();
                ITree queryTree = TreeUtilities.GetTreeFromTableName(qTreeTableName);
                ITree referenceTree = TreeUtilities.GetTreeFromTableName(rTreeTableName);
                InitDataStructures(queryTree, referenceTree, qTreeTableName, rTreeTableName, kNN);
                DateTime startTime, endTime;
                TimeSpan duration;
                startTime = DateTime.Now;
                IEnumerable results = DualTreeNearestNeighbors(queryTree, referenceTree, kNN);
                endTime = DateTime.Now;
                duration = endTime - startTime;
                Trace.WriteLine("Dual Tree took = " +
                    duration.Minutes + "m, " + duration.Seconds + "." + duration.Milliseconds + "s");
                Trace.Flush();
                CloseEnvironment();
                return results;
            }
            catch (Exception e)
            {
                Trace.WriteLine("Uh Oh, an exception has occured");
                Trace.WriteLine(e.StackTrace);
                CloseEnvironment();
                throw e;
            }
            
        }

        private IEnumerable DualTreeNearestNeighbors(
            ITree queryTree, ITree refTree, int kNN)
        {
            double queryRefMinSquaredDistance =
                queryTree.GetMinSqEuclideanDst(refTree.GetRoot(), queryTree.GetRoot());

            RecursiveDualTree(queryTree.GetRoot(), refTree.GetRoot(),
                queryRefMinSquaredDistance, kNN);

            Trace.WriteLine("Time: " + new DateTime().TimeOfDay);
            //Trace.WriteLine("Hash Table Size: " + hashTable.Count);
            //Trace.WriteLine("table size : " + table.Count);
            Trace.Flush();

            ArrayList list = new ArrayList();
            IEnumerator<int> it = qIdIndexMapping.Keys.GetEnumerator();
            
            while (it.MoveNext())
            {
                
                int qId = it.Current;
                int qIndex;
                if( ! qIdIndexMapping.TryGetValue(qId, out qIndex) )
                    Console.WriteLine("shout9");
                
                for (int i = 0; i < kNN; i++)
                {
                    OutputData output = new OutputData();
                    output.queryPointId = qId;
                    output.referencePointId = nns[qIndex * kNN + i];
                    output.distance = dsts[qIndex * kNN + i];
                    TraceThisOP(output);
                    list.Add(output);
                }
                
            }

            return list;

        }

        private void TraceThisOP(OutputData o)
        {
            Trace.WriteLine(o.queryPointId + "\t\t" + o.referencePointId + "\t\t" + o.distance);
        }

        private void CompareAndUpdateQueryAndReferenceNodes(INode queryNode, INode refNode)
        {
            //Trace.WriteLine("DualTreeNN.CompareAndUpdateQueryAndReferenceNodes(): Begin.");
            // calculate the mx distance between t

            double maxDistance = queryNode.GetTree().GetMaxSqEuclideanDst(queryNode, refNode);
            //Trace.WriteLine("Gotten : " + maxDistance);
            if (maxDistance < GetNearestNodeMaxDistance(queryNode))
            {
                //Trace.Write("In here");
                SetNearestNodeMaxDistance(queryNode,maxDistance);
                //Trace.WriteLine("Setting Max value to : " + maxDistance);
            }
            //Trace.WriteLine("DualTreeNN.CompareAndUpdateQueryAndReferenceNodes(): End.");
        }

        private void RecursiveDualTree(INode queryNode, INode refNode,
            double queryRootMinSquaredDistance, int kNN)
        {
            
            //Trace.WriteLine("DualTreeNN.RecursiveDualTree(): Begin.");
            //Trace.WriteLineIf(queryNode == null, "query root is null");
            //Trace.WriteLineIf(refNode == null, "ref root is null");

            //Trace.WriteLine("Query box:" + queryNode.getBox());
            //Trace.WriteLine("Ref box:" + refNode.getBox());
            //Trace.WriteLine("Query node current max distance for nearest node:" + queryNode.GetNearestNodeMaxDistance());
            //Trace.WriteLine("Min Distance: " +  queryRootMinSquaredDistance);
            //Trace.WriteLine("Nearest node is at : " + queryNode.GetNearestNodeMaxDistance() + " and dist from this nod is " + queryRootMinSquaredDistance );
            if (GetNearestNodeMaxDistance(queryNode) < queryRootMinSquaredDistance)   // change this eventually to < only
            {
                //Trace.WriteLine("DualTreeNN.RecursiveDualTree(): Ignoring node.");
                //ignore ie excludes
                //Trace.WriteLine("Ignoring");
            }
            else
            {
                //Trace.WriteLine("Here");
                // We must compare the nodes in this case to update the 
                // nearestNodeMaxDistance feild for the query node if this ref node has a lower
                // max distance than the current value if nearestNodeMaxDistance
                //Trace.WriteLine("DualTreeNN.RecursiveDualTree(): Exploring Node");
                CompareAndUpdateQueryAndReferenceNodes(queryNode, refNode);
                //Trace.WriteLine("now nearest node is at " + queryNode.GetNearestNodeMaxDistance());
                //Trace.WriteLine("Query node current max distance for nearest node:" + queryNode.GetNearestNodeMaxDistance());
                // ok now we must check all 4 conditions
                if (queryNode.IsLeaf() && refNode.IsLeaf())
                {
                    //Trace.WriteLine("Case4");
                    SetNearestNeigborsForLeafs(queryNode, refNode,kNN);
                }
                else if (!queryNode.IsLeaf() && !refNode.IsLeaf())
                {
                    // first try and prune one half of the query tree just based on dst
                    // from this query root before going to its children
                    //Trace.WriteLine("Case1");
                    // examine left child and then right child
                    INode LC = queryNode.GetChild(0);
                    double LCLCdist = queryNode.GetTree().GetMinSqEuclideanDst(LC, refNode.GetChild(0));
                    double LCRCdist = queryNode.GetTree().GetMinSqEuclideanDst(LC, refNode.GetChild(1));

                    if (LCLCdist < LCRCdist)
                    {
                        RecursiveDualTree(LC, refNode.GetChild(0), LCLCdist, kNN);
                        RecursiveDualTree(LC, refNode.GetChild(1), LCRCdist, kNN);
                    }
                    else
                    {
                        RecursiveDualTree(LC, refNode.GetChild(1), LCRCdist, kNN);
                        RecursiveDualTree(LC, refNode.GetChild(0), LCLCdist, kNN);
                    }

                    INode RC = queryNode.GetChild(1);
                    double RCLCdist = queryNode.GetTree().GetMinSqEuclideanDst(RC, refNode.GetChild(0));
                    double RCRCdist = queryNode.GetTree().GetMinSqEuclideanDst(RC, refNode.GetChild(1));
                    if (RCLCdist < RCRCdist)
                    {
                        RecursiveDualTree(RC, refNode.GetChild(0), RCLCdist, kNN);
                        RecursiveDualTree(RC, refNode.GetChild(1), RCRCdist, kNN);
                    }
                    else
                    {
                        RecursiveDualTree(RC, refNode.GetChild(1), RCRCdist, kNN);
                        RecursiveDualTree(RC, refNode.GetChild(0), RCLCdist, kNN);
                    }

                }
                else if (queryNode.IsLeaf() && !refNode.IsLeaf())
                {
                    //Trace.WriteLine("Case2");
                    double LCdist = queryNode.GetTree().GetMinSqEuclideanDst(queryNode, refNode.GetChild(0));
                    double RCdist = queryNode.GetTree().GetMinSqEuclideanDst(queryNode, refNode.GetChild(1));
                    if (LCdist < RCdist)
                    {
                        RecursiveDualTree(queryNode, refNode.GetChild(0), LCdist, kNN);
                        RecursiveDualTree(queryNode, refNode.GetChild(1), RCdist, kNN);
                    }
                    else
                    {
                        RecursiveDualTree(queryNode, refNode.GetChild(1), RCdist, kNN);
                        RecursiveDualTree(queryNode, refNode.GetChild(0), LCdist, kNN);
                    }
                }
                else if (!queryNode.IsLeaf() && refNode.IsLeaf())
                {
                    double LCdist = queryNode.GetTree().GetMinSqEuclideanDst(queryNode.GetChild(0), refNode);
                    double RCdist = queryNode.GetTree().GetMinSqEuclideanDst(queryNode.GetChild(1), refNode);
                    RecursiveDualTree(queryNode.GetChild(0), refNode, LCdist, kNN);
                    RecursiveDualTree(queryNode.GetChild(1), refNode, RCdist, kNN);
                }
            }

        }

        private void GetQueryPoints(INode qNode, out double[] points, out int[] ids)
        {
            if (!queryData.TryGetValue(qNode.GetNodeId(), out points))
                Console.WriteLine("shout1");
            if(!queryIds.TryGetValue(qNode.GetNodeId(), out ids))
                Console.WriteLine("shout2");
            
        }

        private void GetReferencePoints(INode rNode, out double[] points, out int[] ids)
        {
            if( !refData.TryGetValue(rNode.GetNodeId(), out points))
                Console.WriteLine("shout3 " + rNode.GetNodeId());
            if(! refIds.TryGetValue(rNode.GetNodeId(), out ids))
                Console.WriteLine("shout4 " + rNode.GetNodeId());
        }

        private double GetSqDistance(double[] q, int i, double[] r, int j, int k)
        {
            double dst = 0;
            for (int p = 0; p < k; ++p)
            {
                dst += (q[i * k + p] - r[j * k + p]) * (q[i * k + p] - r[j * k + p]);
            }
            return dst;
        }

        private void SetNearestNeigborsForLeafs(
            INode queryNode, INode refNode, int kNN)
        {
            int k = queryNode.GetTree().GetDimensionality();
            //Trace.WriteLine("SingleTreeNN.getNearestNeigborForSingleQuery");
            int I = queryNode.GetNumPoints();
            int J = refNode.GetNumPoints();
            double[] queryPoints, refPoints;
            int[] queryIds, refIds;
            GetQueryPoints(queryNode, out queryPoints, out queryIds);
            GetReferencePoints(refNode, out refPoints, out refIds);

            if (queryPoints.Length != I * k || queryIds.Length != I)
                Console.WriteLine("shout4");
            if (refPoints.Length != J * k || refIds.Length != J)
                Console.WriteLine("shout5");
            
            
            for (int i = 0; i < I; ++i)
            {
                
                int queryPointIdx;
                if( !qIdIndexMapping.TryGetValue(queryIds[i], out queryPointIdx))
                    Console.WriteLine("shout10"); 
                double maxDistance = maxDist[queryPointIdx];
                for (int j = 0; j < J; ++j)
                {
                   
                    double distance = GetSqDistance(queryPoints, i, refPoints, j, k);
                    // nns dsts maxDst
                    if (distance < maxDistance)
                    {
                        //Console.Write("setting" + 
                        // this distance should go into the nn list for this query
                        // put this one in the max's position and change maxDst and maxDistance
                        
                        maxDistance = AddNearestNeighbor(queryIds[i], refIds[j], distance, maxDistance, kNN);

                       

                    }
                }
                // Trace.WriteLine("");
            }
        }

        private double AddNearestNeighbor(int qId, int rId, double distance, double maxDistance, int kNN)
        {
            

            double secondLargest = -1;
            int maxIdx = -1;
            int qIndex;
            if( !qIdIndexMapping.TryGetValue(qId, out qIndex) )
                Console.WriteLine("shout8");
            if (qId == 75)
            {
            
                Console.WriteLine("Before");
                Console.Write("Dsts [");
                for (int i = 0; i < kNN; ++i)
                {
                    Console.Write(dsts[qIndex * kNN + i] + ",");
                }
                Console.WriteLine("]");

                Console.Write("ids [");
                for (int i = 0; i < kNN; ++i)
                {
                    Console.Write(nns[qIndex * kNN + i] + ",");
                }
                Console.WriteLine("]");
                Console.WriteLine(" Max Distance = " + maxDist[qIndex]);


            }

            for(int i = 0; i < kNN; ++i)
            {
                if (dsts[qIndex*kNN + i] == maxDistance)
                {
                    maxIdx = i;
                    for ( int j = i + 1; j < kNN; ++j)
                    {
                        if (secondLargest < dsts[qIndex * kNN + j])
                        {
                            secondLargest = dsts[qIndex * kNN + j];
                        }
                    }
                    break;
                }
                else if( secondLargest < dsts[qIndex*kNN + i] )
                {
                    secondLargest = dsts[qIndex*kNN + i];
                    

                }
            }



            // update nns etc
            nns[qIndex*kNN + maxIdx] = rId;
            dsts[qIndex*kNN + maxIdx] = distance;

            if (qId == 75)
            {

                Console.WriteLine("second largest : " + secondLargest + "\n");
            }
            // check if second largest idx was updated. it will only not
            // get updated if the whole array of dsts contains only max distances
            // for this queryid. In this case maxIdx is gaurunteed to end up as kNN-1
            // and thus setting the second largest ids and value to 0 index does the trick
            if (secondLargest == -1) 
            { 
                // it wasn't. set the value to 
                secondLargest = dsts[qIndex * kNN];
               
                //secondLargestIdx = 0;
                
            }

            if (qId == 75)
            {

                Console.WriteLine("second largest : " + secondLargest + "\n");
            }
    
            maxDist[qIndex] = secondLargest > distance? secondLargest : distance;
            /*
            if (qId == 75)
            {
                Console.WriteLine("After");
            
                Console.Write("Dsts [");
                for (int i = 0; i < kNN; ++i)
                {
                    Console.Write(dsts[qIndex * kNN + i] + ",");
                }
                Console.WriteLine("]");

                Console.Write("ids [");
                for (int i = 0; i < kNN; ++i)
                {
                    Console.Write(nns[qIndex * kNN + i] + ",");
                }
                Console.WriteLine("]");
                Console.WriteLine(" Max Distance = " + maxDist[qIndex]);


            }
            */
            return maxDist[qIndex];

        }
        /// <summary>
        /// Returns the maximum distance between this node and any previous node.
        /// </summary>
        /// <param name="node"></param>
        /// <returns></returns>
        private double GetNearestNodeMaxDistance(INode queryNode)
        {
            int index;
            if( !nodeIdIndexMapping.TryGetValue(queryNode.GetNodeId(), out index) )
                Console.WriteLine("shout7");
            //Trace.WriteLine("returning :" + NodeMaxDst[index]);
            return NodeMaxDst[index];
        }

        private void SetNearestNodeMaxDistance(INode queryNode, double maxDistance)
        {
            int index;
            if( !nodeIdIndexMapping.TryGetValue(queryNode.GetNodeId(), out index) )
                Console.WriteLine("shout6");
            //Trace.WriteLine("setting :" + maxDistance);
            NodeMaxDst[index] = maxDistance;
        }
    }
}